matrix.exe

Designed by: Ali Al-Senan
	     Benjamin Linam

We did not encounter any serious problems during design of program.  We completed the code fairly quickly.  Understanding what "reading" data meant was what took the longest amount of time.  Program runs as expected and required by project instruction page.